/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author harjot kaur
 */
class User {
    private String name,type,price,id;
    
    public User(String name,String type,String price,String id)
    {
        this.name=name;
        this.type=type;
        this.price=price;
        this.id=id;
    }
    public String getname()
    {
        return name;
    }
     public String gettype()
    {
        return type;
    }
      public String getprice()
    {
        return price;
    }
       public String getid()
    {
        return id;
    }
}
