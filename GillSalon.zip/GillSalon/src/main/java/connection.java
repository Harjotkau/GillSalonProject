
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author harjot kaur
 */
public class connection {
    public static void main(String[] args) throws SQLException{
        Connection conn =null;
        
        try{
            
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/login","root","admin@123");
            if(conn!=null)
            {
                System.out.println("connected to database successfully");
            }
            }catch(Exception ex){
            System.out.println("There were errors while connecting to db.");
           
        }
    }
}
